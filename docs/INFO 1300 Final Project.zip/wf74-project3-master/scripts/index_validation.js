// when user submits vendor nomination form
$("#VnominateForm").on("submit", function() {
  var formValid = true;

  // Check whether the vendor name was provided and show an error if not.
  if( $("#vendorName").prop("validity").valid ) {
    $("#vendorNameFeedback").addClass("hidden");
  } else {
    $("#vendorNameFeedback").removeClass("hidden");

    formValid = false;
  };

  // Check whether the vendor desciption is valid and show an error if not.
  if( $("#vendorDescription").prop("validity").valid ) {
    $("#vendorDescriptionFeedback").addClass("hidden");
  } else {
    $("#vendorDescriptionFeedback").removeClass("hidden");

    formValid = false;
  };

  return formValid;
});

// when user submits event nomination form
$("#EnominateForm").on("submit", function() {
  var formValid = true;

  // Check whether the event name was provided and show an error if not.
  if( $("#eventName").prop("validity").valid ) {
    $("#eventNameFeedback").addClass("hidden");
  } else {
    $("#eventNameFeedback").removeClass("hidden");

    formValid = false;
  };

  // Check whether the event desciption is valid and show an error if not.
  if( $("#eventDescription").prop("validity").valid ) {
    $("#eventDescriptionFeedback").addClass("hidden");
  } else {
    $("#eventDescriptionFeedback").removeClass("hidden");

    formValid = false;
  };

  return formValid;
});


// when user submits vendor rating form.
$("#VrateForm").on("submit", function() {
  var formValid = true;

  // Check if atleast one vendor was ranked (if one box has a value) and show an error if not.
  if( $("#vendorRank1").val() || $("#vendorRank2").val() || $("#vendorRank3").val() || $("#vendorRank4").val() || $("#vendorRank5").val() || $("#vendorRank6").val() ) {
    $("#VrateFormFeedback").addClass("hidden");
  } else {
    $("#VrateFormFeedback").removeClass("hidden");
    formValid = false;
  };

  return formValid;
});

// when user submits event rating form.
$("#ErateForm").on("submit", function() {
  var formValid = true;

  // Check if atleast one event was ranked (if one box has a value) and show an error if not.
  if( $("#eventRank1").val() || $("#eventRank2").val() ) {
    $("#ErateFormFeedback").addClass("hidden");
  } else {
    $("#ErateFormFeedback").removeClass("hidden");
    formValid = false;
  };

  return formValid;
});
