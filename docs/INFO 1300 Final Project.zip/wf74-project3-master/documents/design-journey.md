# Project 3: Design Journey

**For milestones, complete only the sections that are labeled with that milestone.**

Be clear and concise in your writing. Bullets points are encouraged.

**Everything, including images, must be visible in Markdown Preview.** If it's not visible in Markdown Preview, then we won't grade it. We won't give you partial credit either.

**Make the case for your decisions using concepts from class, as well as other design principles, theories, examples, and cases from outside of class.**

You can use bullet points and lists, or full paragraphs, or a combination, whichever is appropriate. The writing should be solid draft quality but doesn't have to be fancy.

## Project 1 or Project 2
> Which project will you add a form to?

Project 2


## Audience (Milestone 1)
> Who is your site's target audience? This should be the original audience from Project 1 or Project 2. You may adjust the audience if necessary. Just make sure you explain your rationale for doing so here.

The site's target audience will be locals (people that are in Ithaca for a majority of the year, includes students) who have been to the Ithaca Apple Harvest Festival atleast once before. I do not want to target people outside of Ithaca as they are not very likely to go to the festival. I do not want to target people who have never been to the festival, atleast at first. The purpose of this website is to draw more traffic to the festival. The easiest place to start in my opinion is attempting to get people who have a previous understanding of the festival and try to persuade them to return. The festival needs people to go every year.


## Audience's Needs (Milestone 1)
> List the audience's needs that you identified in Project 1 or 2. Just list each need. No need to include the "Design Ideas and Choices", etc. You may adjust the needs if necessary. However, any changes you make to the needs for this project should be clearly identified and justified.

- Need 1: A food product that could incentivize them to go to the festival
- Need 2: An apple related product that could incentivize them to go to the festival

- These four were not specifically mentioned in interview questions before but were addressed by my project 2 site. I think they are important aspects that visitors to the festival would appreciate.

  - Need 3: A way to interact with the festival through social media
  - Need 4: A way to keep up with the festival
  - Need 5: Information about parking
  - Need 6: Information about events
  - Need 7: Give feedback on products, vendors, events


## HTML Form + User Needs Brainstorming (Milestone 1)
> Using the audience needs you identified, brainstorm possible options for an HTML form for the site. List each idea and provide a brief rationale for how the HTML form addresses that need.

- Form that allows anyone to nominate companies as vendors. This could allow the festival staff to discover new companies to work with and people could have input into vendors they want to see at the festival.
- Form that allows people to rank vendors at the festival. This could tell festival staff which vendors are the most popular and allows people to feel like they have a say in which vendors are at the festival.
- Form that allows people to rank events at the festival. This could tell festival staff which events are the most popular and allows people to feel like they have a say in which events are at the festival.
- Form for people to register their visit. There could be some sort of incentive for this. Maybe a small free item. This could help festival staff see which days the most and least people are visiting.


## HTML Form Proposal & Rationale (Milestone 1)
> Make a decision about your site's form. Describe the purpose of your proposed form for your Project 1 or 2 site. Provide a brief rationale explaining how your proposed form meets the needs of your site's audience.
> Note: If your form is a contact form, we expect to see a thorough justification explaining how a contact form addresses the user's _actual_ needs. In your justification explain how a contact form better suits the needs of your user compared to the alternatives (e.g. sending you an email using your email address).

Form Proposal: Rank/Nominate Vendors and Events

User Needs Rational: This form will allow the user to rank events and vendors after visiting the festival. It will also have a section for them to nominate vendors and give suggestions for events. This suits the users needs because they will be incentivized to go to the festival if something they nominate or suggest is implemented. People will feel that their voice is being heard and more connected to the festival. This will also help the festival staff determine which vendors and events are the most popular, influencing their decision on what to include at the festival.


## Form User Data (Milestone 1)
> Think through and plan the data you need to collect from the users. Do you need their name? Email address? etc.

- Their ranking of vendors from a set list

- Their ranking of events from a set list

- Name of the company they want to nominate to be a vendor
- A brief description of the product the company sells

- Name of an event the user wants to suggest
- A brief desciption of the event the user wants to suggest
- Name of the user suggesting an event so they can be contacted if the event is feasible
- Email of the user suggesting an event


## Form Components & Validation Criteria (Milestone 1)
> For each piece of data you plan to collect from the users, identify an appropriate HTML component to collect that data and decide the validation criteria (e.g. whether this data is _required_). Briefly explain your reasoning for the component choice and the validation criteria.

- Vendor Ranking (required): Drop down list box; `<select name="vendor_ranking_1to6">`
  - This will be a list with the name of the vendor on the left and drop down list box to the right of the vendor name where a rank can be assigned.
  - Text: Robbies Product Farm Market                   `<options value="1">`, `<options value="2">`, `<options value="3">` ... etc.
  - Text: AJ Teeter Farm                                `<options value="1">`, `<options value="2">`, `<options value="3">` ... etc.

- Events Ranking (required): Drop down list box; `<select name="event_ranking_1to2">`
  - This will be a list with the name of the event on the left and drop down list box to the right of the event name where a rank can be assigned.
  - Text: Apple & Cider Trail                          `<options value="1">`, `<options value="2">`
  - Text: Finger Lakes Cider Week                      `<options value="1">`, `<options value="2">`

- Vendor Nomination Company Name (optional): Single-line text input; `<input type="text" name="vendor_name">`
- Vendor Nomination Brief Description (optional): Multi-line text input; `<textarea name = "vendor_description">`

- Event Suggestion Name (optional): Single-line text input; `<input type="text" name="event_name">`
- Event Suggestion Brief Description (optional): Multi-line text input; `<textarea name = "event_description">`
- User Name (optional): Single-line text input; `<input type="text" name="user_name">`
- User Email (optional): Single-line text input; `<input type="text" name="user_email">`

I chose to use a list with a dropdown list on to the right with ranking options because I think this make the most sense to the user. They have six options for vendors, six options for "scores" on the right. Assign one to each. I think the vendor and event nomination components are fairly straight forward, simple single-line and multi-line text inputs.

## Form Location (Milestone 1)
> Which HTML file will you place your form?

(index.html)

> Sketch the location of the form in that page. This sketch need not be fancy. You don't need to provide many details of the page or form. Just plan the location of the form on the page and communicate that to us. You can literally have a box that says "FORM HERE."

**Location**

![vendor form](vendor form.png)

## Form Design (Milestone 1)
> Include sketches on your form below. Include sketches of your **mobile and desktop** versions without corrective feedback. Show us the evolution of your design and the alternatives you considered.

**Sketch**

![form](form.png)

## Form Feedback Design (Milestone 1)
> Include sketches of your **mobile and desktop** with _corrective feedback_. Show us the evolution of your design and the alternatives you considered.

**Feedback**

![index full](index full.png)

I moved the form to the home page after feedback. It makes more sense, it was only on vendors at first because I was originally planning to just nominate and rank vendors.

## Form Implementation Planning (Milestone 1)
> What submission method will your form use? GET or POST. Explain your reasoning.

The single-line text inputs will use GET. The multi-line text inputs should use POST as they could be fairly long. The ranking drop down list boxes should be adding information to a database, so they should all use POST.

> For your site's `<form>` element, plan all HTML attributes that you will need and their values. Hint: action=, method=, novalidate

Single-line text input:
- `<input type="text">`
- `<name="event_name">`
- `<method="get">`

Multi-line text input:
- `<textarea name = "event_description">`
- `<cols="20">`
- `<rows="4">`
- `<method="post">`

Drop down list boxes:
- `<select name="vendor_ranking_1to6">`
- `<options value="1">`, `<options value="2">`, `<options value="3">` ... etc.
- `<method="post">`

## Additional Information (Milestone 1)
> (optional) Include any additional information, justifications, or comments we should be aware of.

I do not think I need to include mobile design sketch image because of the way I set up my responsive design for project 2. Instead of using breakpoints, I used percentages for width values and nested div boxes, keeping everything in line. I have thoroughly tested this.


## Plan Validation Pseudocode (Final Submission)
> Write your form validation pseudocode here.

```

// when user submits vendor nomination form ("On Form Submit Event" snippet):

	// if vendor name component is valid ("Check Component Validity" snippet):
		// hide  vendor name feedback
	// else
		// show vendor name feedback


	// if vendor description component is valid ("Check Component Validity" snippet):
		// hide vendor description feedback
	// else
		// show vendor description feedback

// send form to server if formValid is true (included as part of "On Form Submit Event" snippet)


// when user submits event nomination form ("On Form Submit Event" snippet):

	// if event name component is valid ("Check Component Validity" snippet):
		// hide  event name feedback
	// else
		// show event name feedback


	// if event description component is valid ("Check Component Validity" snippet):
		// hide event description feedback
	// else
		// show event description feedback

// send form to server if formValid is true (included as part of "On Form Submit Event" snippet)


// when user submits vendor rating form ("On Form Submit Event" snippet):

	// if at least one of the vendor rank components has a value ("At Least One Component Has A Value" snippet):
		// hide vendor rating form feedback
	// else
		// show vendor rating form feedback

// send form to server if formValid is true (included as part of "On Form Submit Event" snippet)


// when user submits event rating form ("On Form Submit Event" snippet):

	// if at least one of the event rank components has a value ("At Least One Component Has A Value" snippet):
		// hide event rating form feedback
	// else
		// show event rating form feedback

// send form to server if formValid is true (included as part of "On Form Submit Event" snippet)

```


## Additional Design Justifications (Final Submission)
> If you feel like you haven’t fully explained your design choices in the final submission, or you want to explain some functions in your site (e.g., if you feel like you make a special design choice which might not meet the final requirement), you can use the additional design justifications to justify your design choices. Remember, this is place for you to justify your design choices which you haven’t covered in the design journey. Use it wisely. However, you don’t need to fill out this section if you think all design choices have been well explained in the final submission design journey.

At first, I thought my responsive design I originally had for Project 2 was fine, using lots of div boxes to separate and space things, rather than breakpoints. But when I added in the forms at the bottom of the home page, it extended too far down the page to make the overall design functional on mobile devices. Thus, I added in breakpoints in the CSS file that would change the flex-direction of the bottom container on the home page, and a some containers on the events page as well. Also, I couldn't figure out why my feedback messages won't show in a red color. I made a class for them in CSS and added color: red; -- I can't see why this doesn't work.


## Self-Reflection (Final Submission)
> This was the first project in this class where you coded some JavaScript. What did you learn from this experience?

I think JQuery makes Javascript a lot more accessible. I have looked at JavaScipt code before and was very confused, but once I had learned how HTML, CSS and Javascipt all work together from this class, and the role of JQuery, it is more easier to understand. I think Javascipt is fairly basic for structure, but some of the syntax is confusing and seems unnecessary. For example, I still don't entirely understand the need for the dollar symbols and the semi-colons after curly brackets at some points.


> Reflect on how HTML, CSS, and JavaScript together support client-side interactivity. If it's helpful, you can describe your mental model of client-side interactivity or explain how the general idea of showing and hiding content can be used to implement other forms of client-side interactivity beyond form validation and feedback.

HTML defines the structure of your content. It allows you to roughly organize things on your page, mostly vertically and assign classes that will later allow you to chance the appearance of elements with CSS. After linking a CSS file to your HTML file, you can add properties to HTML elements that will affect the appearance, things such as spacing, color, alignment. You can assign these CSS properties to general HTML elements or with specific classes, defined within the HTML. Hierarchy is important in CSS, allowing you to make general templates for certain elements, keeping your design consistent, and then make a child class and make adjustments to individual elements. JavaScipt enable you to read input from the user, generally in terms of actions, such as clicks. Then, apply some type of function that will affect the CSS style of whatever HTML element you are referencing.


> Take some time here to reflect on how much you've learned since you started this class. It's often easy to ignore our own progress. Take a moment and think about your accomplishments in this class. Hopefully you'll recognize that you've accomplished a lot and that you should be very proud of those accomplishments!

I had no solid concept of how websites worked in terms of servers and clientside things. I did not think of websites as a collection of files before this course, so all of the theory was very interesting to me at first and I am glad I learned that. Within HTML, I feel very comfortable now and can easily and quickly design the backbone of a website now. CSS was a little more difficult to me, but when we learned about classes that things started to click for me and I think I have a good grasp of how to style everything now, in groups and individually. Javascipt was really confusing to look at before, as I previously mentioned. Now I understand that it is very similar to other programming languages I know, Java, Python, C#, etc. With a good snippet reference, I can piece together what I need to accomplish with Javascipt now. You just need to find the HTML elements you are trying to reference, the CSS style changes you want to make, and the correct JQuery snippet to connect the two in the way that you want. I have learned a lot, almost everything was new to me in this course, other than basic programming concepts.
