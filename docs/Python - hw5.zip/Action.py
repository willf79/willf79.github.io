from Routes import *
from Commerce import *
from Ships import *
from Ports import *
from tkinter import *


def main(x):

    ships = make_ships('ships.txt')  # these are here as initialized - and outside mainloop function of GUI
    ports = make_ports('ports.txt')
    cargo = make_cargo('cargo.txt')
    routes = make_routes('routes.txt')
    GUIpts = make_pospts("GUIptList.txt")

    manager = FleetManager(1500) # initialize the FleetManager
    for ship in ships:
        manager.add_boat(ship)
    manager.add_cargo(cargo[0])
    manager.addtoship_cargo(ships[3], cargo[0])
    manager.add_balances(manager.get_balance())

    ships[0].set_route(routes[2]) # initialize some ships with routes
    ships[1].set_route(routes[3])
    ships[2].set_route(routes[5])
    ships[3].set_route(routes[4])
    ships[4].set_route(routes[7])


    ships[0].add_cargo(cargo[4])  # initialize some cargo on ships

    ships[0].set_mode("Economy") # initialize ship modes
    ships[1].set_mode("Economy")
    ships[2].set_mode("Economy")
    ships[3].set_mode("Economy")
    ships[4].set_mode("Economy")

    top = Tk()  # mainloop function from tkinter loops here - local def scripts of GUI inside this Loop

    def shipInfo():  # command call from button
        j = Canvas(top, bg="snow", height=105, width=252)
        j.place(x=970, y=133)
        for r in range(len(ships)):
            var = StringVar()
            label = Message(top, width=400, textvariable=var, relief=FLAT, bg="snow", fg="black")
            label.place(x=972, y=136 + r * 20)
            var.set(str(ships[r].get_name()) + "\t is at:  " + str(ships[r].get_currLoc()))

    def guiMove():  # the main step forward move - comes from a button call further down in program.
        y5 = 200
        for ship in ships:
            if ship.get_route() is not None:
                ship.move()
                manager.pay_opCost(ship)
                shipInfo()
                for u in GUIpts:
                    shiproute = str(ship.get_route().get_ID())
                    shippos = str(ship.get_pos())
                    if shiproute == u.get_rtID() and shippos == u.get_pospt():
                        x = int(u.get_x())
                        y = int(u.get_y())
                        size = 4
                        plot = C.create_oval(x - size, y - size, x + size, y + size, fill='red')

                if ship.get_currLoc() == ship.get_route().get_dest():
                    print("Ship " + ship.get_name() + " has arrived!")
                    anchor()
        showFinances()
        if ship.get_currLoc() != ship.get_route().get_dest():
            manager.add_profit(0)
        manager.add_balances(manager.balance)
        # showBoats()
        # showPorts()

    def anchor():
        for ship in ships:
            for p in ports:
                if ship.atPort() is True:
                    var = StringVar()
                    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="snow", fg="black")
                    label.place(x=1280, y=20)
                    var.set(str(ship.get_name()) + " is at Anchorage - Would you like to Dock? ")
                    kButton = Button(top, text=" Dock Ship ", width=16, command=dock, relief=RAISED, fg="Blue")
                    kButton.place(x=1280, y=60)

    def dock():  # comes from a button call - when at dock
        profitcount = 0
        for ship in ships:
            for p in ports:
                if ship.atPort() is True and p.get_name() == ship.get_route().get_dest():
                    print(p.get_name())
                    p.dockBoat(ship)
                    if len(ship.get_cargo()) != 0:
                        for cargo in ship.get_cargo():
                            if cargo.get_dest() == p.get_name():
                                manager.add_balance(int(cargo.get_contrval()))
                                profitcount += int(cargo.get_contrval())
                    ship.set_route(None)
                    manager.sub_balance(int(p.get_dockfee()))

                    j = Canvas(top, bg="snow", height=80, width=250)
                    j.place(x=1240, y=18)

                    var = StringVar()
                    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="snow", fg="black")
                    label.place(x=1280, y=30)
                    var.set(" Docking Completed. ")
        manager.add_profit(profitcount)


    # Console Show Info Functions

    def showFinances():
        print("Finances")
        print("")
        print(" Last Turn Balance: " + str(manager.get_lastbalance()))
        costs = 0
        for ship2 in ships:
            costs += int(ship2.get_opCost())
        print(" Last Turn Costs: " + str(costs))
        print(" Current Balance: " + str(manager.get_balance()))
        cvalue = 0
        for cargo2 in cargo:
            cvalue += int(cargo2.get_contrval())
        print(" Current Value of All Cargo: " + str(cvalue))
        print("")
        print(" Last Turn Profit: " + str(manager.get_lastprofit()))
        print(manager.get_profits())


        j = Canvas(top, bg="snow", height=80, width=200)
        j.place(x=980, y=295)
        var = StringVar()
        label = Message(top, width=110, textvariable=var, relief=FLAT, bg="snow", fg="black")
        label.place(x=980, y=300)
        var.set("Finance Summary : ")
        var = StringVar()
        label = Message(top, width=2000, textvariable=var, relief=FLAT, bg="snow", fg="black")
        label.place(x=980, y=320)
        var.set(" Current Balance: " + str(manager.get_balance()))
        var = StringVar()
        label = Message(top, width=2000, textvariable=var, relief=FLAT, bg="snow", fg="black")
        label.place(x=980, y=340)
        var.set("     Last Turn Costs: " + str(costs))
        var = StringVar()
        label = Message(top, width=2000, textvariable=var, relief=FLAT, bg="snow", fg="black")
        label.place(x=980, y=360)
        var.set("     Last Turn Profits: " + str(manager.get_lastprofit()))


    def showBoats():
        print("Ships")
        print("")
        for ship3 in ships:
            print(ship3.get_name())
            if ship3.get_route() is not None:
                print(" Route: " + ship3.get_route().get_name())
            else:
                print(" Route: None")
            print(" Location: " + str(ship3.get_currLoc()))
            print(" Fuel: " + str(ship3.get_fuel()))
            print(" Mode: " + str(ship3.get_mode()))
            print("")

    def showPorts():
        print("Ports")
        print("")
        for port in ports:
            print(port.get_name())
            print(" Fuel Price: " + str(port.get_fuelprice()))
            print(" Cargo at " + port.get_name() + ":")
            print("")
            for cargo2 in cargo:
                if cargo2.get_start() == port.get_name():
                    print("    Cargo " + str(cargo2.get_ID()+1))
                    print("    Units: " + str(cargo2.get_units()))
                    print("    Pay: " + str(cargo2.get_contrval()))
                    print("    Route: " + cargo2.get_start() + " to " + cargo2.get_dest())
                    print("")
            print("")


    # Plot Points for GUI  --- i optimized this - but had a bug that I induced and didn't get to...

    def rp():
        rp_list = read_lines("rplist.txt")
        for q in range(len(rp_list)):
            rp_info = rp_list[q].split()  # Get bus info for one line in the read out file
            x7 = int(rp_info[0])
            y7 = int(rp_info[1])
            size = 4
            temp = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='light grey')
        rp2_list = read_lines("rplist2.txt")
        for h in range(len(rp2_list)):
            rp2_info = rp2_list[h].split()  # Get bus info for one line in the read out file
            x7 = int(rp2_info[0])
            y7 = int(rp2_info[1])
            size = 4
            one = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='white')

        rp3_list = read_lines("rplist3.txt")
        for h in range(len(rp3_list)):
            rp3_info = rp3_list[h].split()  # Get bus info for one line in the read out file
            x7 = int(rp3_info[0])
            y7 = int(rp3_info[1])
            size = 4
            one = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='white')

        rp4_list = read_lines("rplist4.txt")
        for h in range(len(rp4_list)):
            rp4_info = rp4_list[h].split()  # Get bus info for one line in the read out file
            x7 = int(rp4_info[0])
            y7 = int(rp4_info[1])
            size = 4
            one = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='white')

        rp5_list = read_lines("rplist5.txt")
        for h in range(len(rp5_list)):
            rp5_info = rp5_list[h].split()  # Get bus info for one line in the read out file
            x7 = int(rp5_info[0])
            y7 = int(rp5_info[1])
            size = 4
            one = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='white')

        rp7_list = read_lines("rplist7.txt")
        for h in range(len(rp7_list)):
            rp7_info = rp7_list[h].split()  # Get bus info for one line in the read out file
            x7 = int(rp7_info[0])
            y7 = int(rp7_info[1])
            size = 4
            one = C.create_oval(x7 - size, y7 - size, x7 + size, y7 + size, fill='light grey')


    # Main GUI Program
    top.geometry('1500x900')

    # creates main white canvas and png background
    C = Canvas(top, bg="white", height=900, width=1500)
    filenamez = PhotoImage(file="atlantic.png")
    C.create_image(0, 50, image=filenamez, anchor='nw')
    C.pack()

    # Creates GUI title
    var = StringVar()
    label = Message(top, width=400, textvariable=var, relief=FLAT, font=24, bg="white", fg="black")
    label.place(x=10, y=10)
    var.set("   Willem Fargo - Atlantic Shipping Model   ")

    # some workspaces
    j = Canvas(top, bg="snow", height=80, width=250)
    j.place(x=1240, y=18)

    # places Port dots
    NYx = 200
    NYy = 450
    size = 4
    NY = C.create_oval(NYx - size, NYy - size, NYx + size, NYy + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=150, y=420)
    var.set("New York")

    Hx = 300
    Hy = 420
    size = 4
    H = C.create_oval(Hx - size, Hy - size, Hx + size, Hy + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=270, y=390)
    var.set("Halifax")

    Nx = 90
    Ny = 520
    size = 4
    N = C.create_oval(Nx - size, Ny - size, Nx + size, Ny + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=50, y=490)
    var.set("Savannah")

    Gx = 880
    Gy = 210
    size = 4
    G = C.create_oval(Gx - size, Gy - size, Gx + size, Gy + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=850, y=180)
    var.set("Gothenburg")

    Gx = 830
    Gy = 370
    size = 4
    G = C.create_oval(Gx - size, Gy - size, Gx + size, Gy + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=830, y=385)
    var.set("Brest")

    Gx = 825
    Gy = 500
    size = 4
    G = C.create_oval(Gx - size, Gy - size, Gx + size, Gy + size, fill='black')
    var = StringVar()
    label = Message(top, width=200, textvariable=var, relief=FLAT, bg="grey", fg="black")
    label.place(x=840, y=480)
    var.set("Lisbon")


    def CargoInfo():  # command call from button
        j = Canvas(top, bg="snow", height=240, width=220)
        j.place(x=1250, y=133)
        for r in range(len(cargo)):
            var = StringVar()
            label = Message(top, width=200, textvariable=var, relief=FLAT, bg="snow", fg="black")
            label.place(x=1250, y=136 + r * 20)
            var.set(str(cargo[r].get_ID()) + ".  " + str(cargo[r].get_units()) +" U, $"+ str(cargo[r].get_contrval())+ ": " + str(cargo[r].get_start())+"-"+str(cargo[r].get_dest()))


    def threeway():   # called from 3 way checkboxes in  GUI --- sets route or loads cargo on a ship
        q = int(cv1.get())
        o = int(cv2.get())
        v = int(cp.get())
        print(q)
        print(o)
        print(v)
        if ships[q - 1].get_currLoc() is not None:
            loc = ships[q - 1].get_currLoc()
            locsplit = loc.split()

        if v != 0 and q != 0:
            if locsplit[0] == cargo[v - 1].get_start():
                j = Canvas(top, bg="white", height=20, width=160)
                j.place(x=985, y=445)
                ships[q - 1].add_cargo([v - 1])
                print(str(ships[q - 1].get_name()) + " has " + str(cargo[v - 1].get_units()) + " more cargo")
                var = StringVar()
                label = Message(top, width=200, textvariable=var, relief=FLAT, bg="snow", fg="black")
                label.place(x=985, y=445)
                var.set(str(ships[q - 1].get_name()) + " has " + str(cargo[v - 1].get_units()) + " more cargo")
            else:
                print("You and cargo need to be at same port")

        if o != 0 and q != 0:
            if locsplit[0] == routes[o-1].get_start():
                j = Canvas(top, bg="white", height=20, width=160)
                j.place(x=985, y=445)
                ships[q - 1].set_route(routes[o - 1])
                ships[q - 1].set_pos(0)
                print(ships[q - 1].get_route().get_name())
                print(ships[q - 1].get_currLoc())
                print(str(ships[q - 1].get_name()) + " now on " + routes[o - 1].get_name())
                var = StringVar()
                label = Message(top, width=200, textvariable=var, relief=FLAT, bg="snow", fg="black")
                label.place(x=985, y=445)
                var.set(str(ships[q - 1].get_name()) + " now on " + str(routes[o - 1].get_name()))
            else:
                print("Must be at Embarking point")


    # Button calls
    aButton = Button(top, text="Move Ships", width=16, command=guiMove, relief=RAISED, fg="Blue")
    aButton.place(x=980, y=30)

    bButton = Button(top, text="Clear Trails", width=16, command=rp, relief=RAISED, fg="Blue")
    bButton.place(x=980, y=60)

    cButton = Button(top, text="Cargo Available?", width=16, command=CargoInfo, relief=RAISED, fg="Blue")
    cButton.place(x=980, y=90)

    # dButton = Button(top, text="Save and exits?", width=16, command=save, relief=RAISED, bg= "light blue", fg="Blue")
    # dButton.place(x=980, y=680)


    var = StringVar()
    label = Message(top, width=410, textvariable=var, relief=FLAT, bg="snow", fg="black")
    label.place(x=980, y=420)
    var.set(" Tick the boxes to add cargo and/or select a new route when in port ")

    cv1 = IntVar()
    s1 = Checkbutton(top, text="SS_Moneymaker", variable=cv1, command=threeway, onvalue=1, bg="snow")
    s2 = Checkbutton(top, text="SS_Brunson", variable=cv1, command=threeway, onvalue=2, bg="snow")
    s3 = Checkbutton(top, text="SS_Hellmuth", variable=cv1, command=threeway, onvalue=3, bg="snow")
    s4 = Checkbutton(top, text="SS_Negreanu", variable=cv1, command=threeway, onvalue=4, bg="snow")
    s5 = Checkbutton(top, text="SS_TomDwan", variable=cv1, command=threeway, onvalue=5, bg="snow")
    s6 = Checkbutton(top, text="SS_Esfandiari", variable=cv1, command=threeway, onvalue=6, bg="snow")
    s1.place(x=985, y=480)
    s2.place(x=985, y=500)
    s3.place(x=985, y=520)
    s4.place(x=985, y=540)
    s5.place(x=985, y=560)
    s6.place(x=985, y=580)

    cv2 = IntVar()
    C1 = Checkbutton(top, text="Sav_NY", variable=cv2, command=threeway, onvalue=1, bg="snow")
    C2 = Checkbutton(top, text="NY_Bre", variable=cv2, command=threeway, onvalue=2, bg="snow")
    C3 = Checkbutton(top, text="NY_Hal", variable=cv2, command=threeway, onvalue=3, bg="snow")
    C4 = Checkbutton(top, text="Hal_Got", variable=cv2, command=threeway, onvalue=4, bg="snow")
    C5 = Checkbutton(top, text="Got_Bre", variable=cv2, command=threeway, onvalue=5, bg="snow")
    C6= Checkbutton(top, text="Bre_NY", variable=cv2, command=threeway, onvalue=6, bg="snow")
    C7= Checkbutton(top, text="Bre_Lis", variable=cv2, command=threeway, onvalue=7, bg="snow")
    C8 = Checkbutton(top, text="Lis_Sav", variable=cv2, command=threeway, onvalue=8, bg="snow")
    C1.place(x=1120, y=480)
    C2.place(x=1120, y=500)
    C3.place(x=1120, y=520)
    C4.place(x=1120, y=540)
    C5.place(x=1120, y=560)
    C6.place(x=1120, y=580)
    C7.place(x=1120, y=600)
    C8.place(x=1120, y=620)

    cp = IntVar()
    g1 = Checkbutton(top, text="0", variable=cp, command=threeway, onvalue=1, bg="snow")
    g2 = Checkbutton(top, text="1", variable=cp, command=threeway, onvalue=2, bg="snow")
    g3 = Checkbutton(top, text="2", variable=cp, command=threeway, onvalue=3, bg="snow")
    g4 = Checkbutton(top, text="3", variable=cp, command=threeway, onvalue=4, bg="snow")
    g5 = Checkbutton(top, text="4", variable=cp, command=threeway, onvalue=5, bg="snow")
    g6 = Checkbutton(top, text="5", variable=cp, command=threeway, onvalue=6, bg="snow")
    g7 = Checkbutton(top, text="6", variable=cp, command=threeway, onvalue=7, bg="snow")
    g8 = Checkbutton(top, text="7", variable=cp, command=threeway, onvalue=8, bg="snow")
    g9 = Checkbutton(top, text="8", variable=cp, command=threeway, onvalue=9, bg="snow")
    g10 = Checkbutton(top, text="9", variable=cp, command=threeway, onvalue=10, bg="snow")
    g1.place(x=1250, y=480)
    g2.place(x=1250, y=500)
    g3.place(x=1250, y=520)
    g4.place(x=1250, y=540)
    g5.place(x=1250, y=560)
    g6.place(x=1250, y=580)
    g7.place(x=1250, y=600)
    g8.place(x=1250, y=620)
    g9.place(x=1250, y=640)
    g10.place(x=1250, y=660)

    C.pack()
    top.mainloop()

# Read Files
def read_lines(filename):
    """
    Returns all of the lines of text in a list, read from the designated file
    corresponding to the string filename.
    """
    out = []
    with open(filename, 'r') as file:
        for line in file.read().splitlines():  # loops over each line in file, not including newline
            out.append(line)
    return out


def make_ships(filename):
    """
    Creates the ships utilized by the model by reading data from the provided filename.
    """
    s_list = read_lines(filename)
    for x in range(len(s_list)):
        ship_info = s_list[x].split()  # Get bus info for one line in the read out file

        name = ship_info[0]
        capacity = ship_info[1]
        opCost = ship_info[2]
        startfuel = ship_info[3]

        s_list[x] = Ship(name, capacity, opCost, startfuel)
    return s_list

def make_ports(filename):
    """
    Creates ports utilized by the model by reading data from the provided filename.
    """
    p_list = read_lines(filename)
    for p in range(len(p_list)):
        port_info = p_list[p].split()  # Get port info for one line in the read out file

        name = port_info[0]
        numdocks = port_info[1]
        startfuelprice = port_info[2]
        dockfee = port_info[3]
        anchorfee = port_info[4]
        loadfee = port_info[5]

        p_list[p] = Port(name, numdocks, startfuelprice, dockfee, anchorfee, loadfee)
    return p_list

def make_cargo(filename):
    """
    Creates cargo utilized by the model by reading data from the provided filename.
    """
    c_list = read_lines(filename)
    for cg in range(len(c_list)):
        cargo_info = c_list[cg].split()  # Get bus info for one line in the read out file

        units = cargo_info[0]
        contrval = cargo_info[1]
        start = cargo_info[2]
        dest = cargo_info[3]

        c_list[cg] = Cargo(units, contrval, start, dest)
    return c_list


def make_routes(filename):
    """
    Creates routes utilized by the model by reading data from the provided filename.
    """
    r_list = read_lines(filename)
    for rl in range(len(r_list)):
        route_info = r_list[rl].split()

        name = route_info[0]
        start = route_info[1]
        dest = route_info[2]
        numpts = route_info[3]

        r_list[rl] = RoutesMaker(name, start, dest, numpts)
    return r_list


def make_pospts(filename):
    """
    Loads the full set of rt points - X, Y - from file - to use in GUI
    """
    gui_list = read_lines(filename)
    for r3 in range(len(gui_list)):
        gui_info = gui_list[r3].split()

        rtID = gui_info[0]
        pospt = gui_info[1]
        x = gui_info[2]
        y = gui_info[3]

        gui_list[r3] = GUIpt(rtID, pospt, x, y)

    return gui_list



# def save(ships): # need to add other files to save
#     """
#     Saves to designated files.
#     Information saved comes from respective parameters.
#     """
#
#     with open("GUIptList.txt", 'w') as file:
#         for pt in GUIpts:
#             line = str(pt.get_rtID()) + ' ' + str(pt.get_pospt()) + ' ' + str(pt.get_x()) + ' ' + str(pt.get_y())
#             file.write(line + '\n')
#
#     with open("cargo.txt", 'w') as file:
#         for item in cargo:
#             line = str(item.get_units()) + ' ' + str(item.get_contrval()) + ' ' + str(item.get_start()) + ' ' + str(
#                 item.get_dest())
#             file.write(line + '\n')
#
#     with open("ports.txt", 'w') as file:
#         for port in ports:
#             line = str(port.get_name()) + ' ' + str(port.get_numdocks()) + ' ' + str(
#                 port.get_startfuelprice()) + ' ' + str(port.get_dockfee()) + ' ' + str(
#                 port.get_anchorfee()) + ' ' + str(port.get_loadfee())
#             file.write(line + '\n')
#
#     with open("routes.txt", 'w') as file:
#         for route in routes:
#             line = str(route.get_name()) + ' ' + str(route.get_start()) + ' ' + str(route.get_dest()) + ' ' + str(
#                 route.get_numpts())
#             file.write(line + '\n')
#
#     with open("ships.txt", 'w') as file:
#         for ship in ships:
#             line = str(ship.get_name()) + ' ' + str(ship.get_capacity()) + ' ' + str(ship.get_opCost()) + ' ' + str(
#                 ship.get_fuel())
#             file.write(line + '\n')
#             exit()
"""
Calls main function for program body - with GUI
"""
main(1)
