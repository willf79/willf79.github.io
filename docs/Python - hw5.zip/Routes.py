class RoutesMaker(object):
    allRoutes = []
    numRts = 0

    def __init__(self, name, start, dest, numpts):
        self.ID = RoutesMaker.numRts
        self.name = name
        self.numpts = int(numpts) + 1
        self.start = start
        self.dest = dest
        self.ptlist = []
        self.ptlist.append(self.start)
        r = 1
        while r < self.numpts:
            self.ptlist.append(r)
            r += 1
        self.ptlist.append(self.dest)
        RoutesMaker.allRoutes.append(self)
        RoutesMaker.numRts += 1

    def get_ID(self): return self.ID
    def get_name(self): return self.name
    def get_start(self): return self.start
    def get_dest(self): return self.dest
    def get_ptlist(self): return self.ptlist
    def get_numpts(self): return self.numpts

class GUIpt(object):
    allpts = []

    def __init__(self, rtID, pospt, x, y):
        self.rtID = rtID
        self.pospt = pospt
        self.x = x
        self.y = y
        GUIpt.allpts.append(self)

    def get_rtID(self): return self.rtID
    def get_pospt(self): return self.pospt
    def get_x(self): return self.x
    def get_y(self): return self.y