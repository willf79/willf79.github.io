class Dock(object):
    numMade = 0

    def __init__(self):
        self.hasBoat = False
        self.ID = Dock.numMade
        Dock.numMade += 1

    def get_ID(self): return self.ID

    def setFull(self):
        self.hasBoat = True

    def setEmpty(self):
        self.hasBoat = False

    def isFull(self):
        if self.hasBoat is True:
            return True
        else:
            return False

    def showStatus(self):
        if self.hasBoat is True:
            print("Occupied")
        else:
            print("Empty")


class Port(object):
    allPorts = []

    def __init__(self, name, numdocks, startfuelprice, dockfee, anchorfee, loadfee):
        self.name = name
        self.fuelprice = startfuelprice
        self.docks = []
        self.anchor = []
        self.dockfee = dockfee
        self.anchorfee = anchorfee
        self.loadfee = loadfee
        for r in range(int(numdocks)):
            self.docks.append(Dock())
        Port.allPorts.append(self)

    # Get Name
    def get_name(self): return self.name

    # Get and Set Fuel Price
    def get_fuelprice(self): return self.fuelprice
    def set_fuelprice(self, newfuelprice): self.fuelprice = newfuelprice

    def get_dock(self, docknum):
        for r in self.docks:
            if r.get_ID() == (int(docknum) - 1):
                return r

    def get_dockfee(self): return self.dockfee

    def get_anchorfee(self): return self.anchorfee

    def get_loadfee(self): return self.loadfee

    def dockBoat(self, boat):
        docked = False
        for dock in self.docks:
            if dock.isFull() is False and docked is False:
                dock.setFull()
                boat.set_currLoc(self.name + " - Dock " + str(dock.get_ID() + 1))
                print(boat.get_name() + " is at " + self.name + ": Dock " + str(dock.get_ID() + 1))
                docked = True

    def anchorBoat(self, boat):
        self.anchor.append(boat)
        print(boat.get_name() + " is anchored!")

    def showDocks(self):
        for r in self.docks:
            print("Dock " + str(r.get_ID()+1))
            r.showStatus()
            print("")

    def get_port(self, portname):
        for r in Port.allPorts:
            if r.get_name() == portname:
                return r





