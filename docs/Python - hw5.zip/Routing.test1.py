from random import randint

#  This one is the random weather one....
 # sometimes the avoidance model wins - and sometimes it loses set on these parameters..:

# nodes are numbered in grid - but also have x, y location
# sets up a grid of size (step) x (step)

z = []
a = []
step = 100
for y in range(step):
    for x in range(step):
        v = randint(0,3)  # randome wave value at 0 to 3...  very localized - only 1 cell - no clusters of storms...
        a = [int(x),int(y),int(v)]
        z.append(a)
#
# #
# stormD2 = 5780
# z[stormD2][2] = 2
# z[stormD2+1][2] = 2
# z[stormD2+2][2] = 2
# z[stormD2+3][2] = 2
# z[stormD2+4][2] = 2
# z[stormD2+100][2] = 2
# z[stormD2+101][2] = 4
# z[stormD2+102][2] = 8
# z[stormD2+103][2] = 4
# z[stormD2+104][2] = 2
# z[stormD2+200][2] = 2
# z[stormD2+201][2] = 8
# z[stormD2+202][2] = 12
# z[stormD2+203][2] = 8
# z[stormD2+204][2] = 2
# z[stormD2+300][2] = 2
# z[stormD2+301][2] = 4
# z[stormD2+302][2] = 8
# z[stormD2+303][2] = 4
# z[stormD2+304][2] = 2
# z[stormD2+400][2] = 2
# z[stormD2+401][2] = 2
# z[stormD2+402][2] = 2
# z[stormD2+403][2] = 2
# z[stormD2+404][2] = 2
#
# stormD2 = 6020
# z[stormD2][2] = 2
# z[stormD2+1][2] = 2
# z[stormD2+2][2] = 2
# z[stormD2+3][2] = 2
# z[stormD2+4][2] = 2
# z[stormD2+100][2] = 2
# z[stormD2+101][2] = 4
# z[stormD2+102][2] = 8
# z[stormD2+103][2] = 4
# z[stormD2+104][2] = 2
# z[stormD2+200][2] = 2
# z[stormD2+201][2] = 8
# z[stormD2+202][2] = 12
# z[stormD2+203][2] = 8
# z[stormD2+204][2] = 2
# z[stormD2+300][2] = 2
# z[stormD2+301][2] = 4
# z[stormD2+302][2] = 8
# z[stormD2+303][2] = 4
# z[stormD2+304][2] = 2
# z[stormD2+400][2] = 2
# z[stormD2+401][2] = 2
# z[stormD2+402][2] = 2
# z[stormD2+403][2] = 2
# z[stormD2+404][2] = 2
#
# stormD2 = 5740
# z[stormD2][2] = 2
# z[stormD2+1][2] = 2
# z[stormD2+2][2] = 2
# z[stormD2+3][2] = 2
# z[stormD2+4][2] = 2
# z[stormD2+100][2] = 2
# z[stormD2+101][2] = 4
# z[stormD2+102][2] = 8
# z[stormD2+103][2] = 4
# z[stormD2+104][2] = 2
# z[stormD2+200][2] = 2
# z[stormD2+201][2] = 8
# z[stormD2+202][2] = 12
# z[stormD2+203][2] = 8
# z[stormD2+204][2] = 2
# z[stormD2+300][2] = 2
# z[stormD2+301][2] = 4
# z[stormD2+302][2] = 8
# z[stormD2+303][2] = 4
# z[stormD2+304][2] = 2
# z[stormD2+400][2] = 2
# z[stormD2+401][2] = 2
# z[stormD2+402][2] = 2
# z[stormD2+403][2] = 2
# z[stormD2+404][2] = 2
#

# set start and end node numbers
D = 60*step-1
S = 40*step

# returns the x, y, v of the D Node - not sure it's used anywhere
xD = z[D][0]
yD = z[D][1]
vD = z[D][2]

# returns the x, y, z of the S Node
xS = z[S][0]
yS = z[S][1]

# set some counters
SumV = 0
dir = ""
moves = 0
dstep = step+1
ustep = step-1


# sets new D location - and returns x, y, v
nD = D
xnD = z[nD][0]
ynD = z[nD][1]
vnD = z[nD][2]

# sets orig nodes away
NodesAway = (yD - yS) + (xD - xS)

# print(z)
print("start = ", z[D], " :", int(D))
print("Dest = ", z[S], " :", int(S))



while NodesAway > 0:

    xnD = z[nD][0]
    ynD = z[nD][1]
    vnD = z[nD][2]
    # print(xnD)
    # print(xS)

    leg = []
    for p in range(15):
        leg.append(p)
    legUp = []
    legLeft = []
    legDown = []
    for p2 in range(3):
        legUp.append(p2)
    for p3 in range(7):
        legLeft.append(p3)
    for p4 in range(3):
        legDown.append(p4)


# this should be recursive -- solve for least wavy pathway - but tried to use Fib method example... got stuck.

    # next 3 nodes - 15 options without reversing direction up vs. down
    leg[0] = z[nD + dstep][2] + z[nD + dstep * 2][2] + z[nD + dstep * 3][2]
    leg[1] = z[nD + dstep][2] + z[nD + dstep * 2][2] + z[nD - 3][2]
    leg[2] = z[nD + dstep][2] + z[nD - 2][2] + z[nD + dstep * 3][2]
    leg[3] = z[nD + dstep][2] + z[nD - 2][2] + z[nD - 3][2]
    leg[4] = z[nD - 1][2] + z[nD + dstep * 2][2] + z[nD + dstep * 3][2]
    leg[5] = z[nD - 1][2] + z[nD + dstep * 2][2] + z[nD - 3][2]
    leg[6] = z[nD - 1][2] + z[nD - 2][2] + z[nD + dstep * 3][2]
    leg[7] = z[nD - 1][2] + z[nD - 2][2] + z[nD - 3][2]
    leg[8] = z[nD - 1][2] + z[nD - 2][2] + z[nD - dstep*3][2]
    leg[9] = z[nD - 1][2] + z[nD - dstep*2][2] + z[nD - 3][2]
    leg[10] = z[nD - 1][2] + z[nD - dstep*2][2] + z[nD - dstep*3][2]
    leg[11] = z[nD - dstep][2] + z[nD - 2][2] + z[nD - 3][2]
    leg[12] = z[nD - dstep][2] + z[nD - 2][2] + z[nD - dstep*3][2]
    leg[13] = z[nD - dstep][2] + z[nD - dstep*2][2] + z[nD - 3][2]
    leg[14] = z[nD - dstep][2] + z[nD - dstep*2][2] + z[nD - dstep*3][2]
    #print(leg)

    legUp = list(leg[:4])
    legLeft = list(leg[4:11])
    legDown = list(leg[11:])
    # print(leg)
    # print(legUp)
    # print(legLeft)
    # print(legDown)

    # if min(legLeft) < min(legDown):
    #     print("Should be Left")

    if xnD == xS:  # checks if on X = 0 line - e.g. don't go past xS.
        if yS == ynD:
            print("arrived")
        elif yS < ynD: # if above the S - than go down
            nD = nD - step
            dir = "down"
            SumV = SumV + z[nD][2]
            moves += 1
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            #print("Going Down xxx ")
            #print("Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD + step # since we know we are below - go up
            dir = "up"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves +=1
            #print("Going Up")
            #print("Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)

    elif yS+(.3*step) < ynD:  # checks to see if we are "above" the 3 node choice band
        # old statement   if z[nD-dstep][2] < z[nD-1][2] and dir != "up":   # checks if "down" is lower fuel than "left"
        if min(legDown) < min(legLeft):
            nD = nD - dstep
            dir = "down"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves +=1
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD - 1  # since not down - than left
            dir = "left"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves +=1
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)

    elif yS-(.3*step) > ynD:  # checks to see if we "below" the 3 node choice band
        # if z[nD+ustep][2] < z[nD-1][2] and dir != "down":   # checks if up is lower fuel than "left"
        if min(legUp) < min(legLeft):
            nD = nD + ustep
            dir = "up"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves +=1
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD - 1 # since not up than left
            dir = "left"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves += 1
            #print("Moved Left")
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)

    else:
        if min(legUp) < min(legLeft) and min(legUp) < min(legDown):
        # if z[nD + ustep][2] < z[nD - 1][2] and z[nD + ustep][2] < z[nD - dstep][2] and dir != "down": # checks if up is lowest fuel
            nD = nD + ustep
            dir = "up"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves += 1
            #print("Moved Up")
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)

        elif min(legDown) < min(legLeft) and min(legDown) < min(legLeft):
        # elif z[nD - dstep][2] < z[nD - 1][2] and z[nD - dstep][2] < z[nD + ustep][2] and dir != "up": # checks if down is lowest fuel
            nD = nD - dstep
            dir = "down"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves +=1
            #print("Moved Down")
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD - 1  # must be left
            dir = "left"
            SumV = SumV + z[nD][2]
            NodesAway = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves += 1
            #print("Moved Left")
            #print("Now at nD ", nD)
            #print(SumV)
            #print("Nodes Away: ", NodesAway)


print("")
print(" running 2nd sim")


#reset and run again - with least moves
nD = D
xnD = z[nD][0]
ynD = z[nD][1]
vnD = z[nD][2]
NodesAway2 = (yD - yS) + (xD - xS)
SumV2 = 0
moves2 = 0
dir2 = ""

while NodesAway2 > 0:

    xnD = z[nD][0]
    ynD = z[nD][1]
    vnD = z[nD][2]
    # print(xnD)
    # print(xS)
    if xnD == xS:
        if yS == ynD:
            print("arrived")
        elif yS < ynD and dir2 != "up":
            nD = nD - step
            dir2 = "down"
            SumV2 = SumV2 + z[nD][2]
            moves2 += 1
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            #print("Going Down xxx ")
            #print("Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD + step
            dir2 = "up"
            SumV2   = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 +=1
            #print("Going Up xxx ")
            #print("Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)

    elif yS < ynD:
        if z[nD-dstep][2] < z[nD-1][2] and dir2 != "up":
            nD = nD - dstep
            dir2 = "down"
            SumV2 = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 +=1
            #print("Moved Down")
            #print(Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)
        else:
            nD = nD - 1
            SumV2 = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 +=1
            #print("Moved left")

    elif yS > ynD:
        if z[nD+ustep][2] < z[nD-1][2] and dir2 != "down":
            nD = nD + ustep
            dir2 = "up"
            SumV2 = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 +=1
            #print("Moved Up")

        else:
            nD = nD - 1
            SumV2 = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 += 1
            #print("Moved Left")
            #print("Now at nD ", nD)
            #print("Nodes Away: ", NodesAway)

    else:
            nD = nD - 1
            SumV2 = SumV2 + z[nD][2]
            NodesAway2 = (z[nD][1] - yS) + (z[nD][0] - xS)
            moves2 += 1
            #print("Moved Left")


print("")
print(" Results")
print("")
print("Moves using some avoidance= ", moves)
print("Optimized Sum of wave values = ", SumV)
print("")
print("Min Moves method - aways goes toward endpoint", moves2)
print("SumV w/Min moves", SumV2)



#   ok - the min model - goes to the latitude - and than across - shortest distance
#    the optimized model - only optimizes 1 cell - so it might get into more weather by not looking ahead ---
#    can we recurse for the lowest value - by looking ahead for lowest value of SumV
#    alternately - we can add like 10 cells forward - and min that... instead... like a tree for 10 levels