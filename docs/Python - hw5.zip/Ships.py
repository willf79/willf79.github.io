class Ship(object):
    allShips = []
    numShips = 0

    def __init__(self, name, capacity, opCost, startfuel):
        self.ID = Ship.numShips
        self.name = name
        self.fuel = float(startfuel)
        self.capacity = capacity
        self.opCost = opCost
        self.pos = 0
        self.route = None
        self.cargo = []
        self.mode = None
        self.currLoc = None
        Ship.allShips.append(self)
        Ship.numShips += 1

    def get_ID(self): return self.ID
    def get_name(self): return self.name

    def get_fuel(self): return self.fuel
    def add_fuel(self, amount): self.fuel += amount
    def sub_fuel(self, amount): self.fuel -= amount

    def get_capacity(self): return self.capacity

    def get_opCost(self): return self.opCost
    def set_opCost(self, opCost): self.opCost = opCost

    def get_pos(self): return self.pos
    def set_pos(self, newpos): self.pos = newpos

    def get_mode(self): return self.mode
    def set_mode(self, newmode): self.mode = newmode

    def atPort(self):
        from Ports import Port
        check = False
        for port in Port.allPorts:
            if self.currLoc == port.get_name():
                check = True
        return check

    def change_mode(self):
        if self.mode == "Economy": self.mode = "Fast"
        if self.mode == "Fast": self.mode = "Economy"

    def get_route(self): return self.route
    def set_route(self, newroute):
        self.route = newroute
        if self.route is not None:
            self.currLoc = self.route.get_ptlist()[0]

    def get_cargo(self): return self.cargo
    def add_cargo(self, shipment): self.cargo.append(shipment)

    def get_currLoc(self): return self.currLoc
    def set_currLoc(self, newcurrLoc): self.currLoc = newcurrLoc

    def move(self):
        if self.pos < self.route.get_numpts():
            if int(self.fuel) > 0:
                if self.mode == "Economy":
                    self.pos = (self.pos + 1)
                    self.sub_fuel(0.75)
                if self.mode == "Fast":
                    if (len(self.route.get_ptlist()) - self.pos) > 2:
                        self.pos = (self.pos + 2)
                        self.sub_fuel(2)
                    else:
                        self.mode = "Economy"
                        self.pos = (self.pos + 1)
                        self.sub_fuel(0.75)
            else:
                print(self.name + " is out of fuel!")

        if self.route is not None:
            self.currLoc = self.route.get_ptlist()[self.pos]


    def full(self):
        return len(self.cargo) == self.capacity