class FleetManager:
    def __init__(self, startbalance = 0, startfuel = 0):
        self.balance = startbalance
        self.boats = []
        self.cargoList = []
        self.fuel = startfuel
        self.balances = []
        self.profits = []

    def get_balance(self): return self.balance
    def add_balance(self, baladd): self.balance += baladd
    def sub_balance(self, balsub): self.balance -= balsub

    def get_balances(self): return self.balances
    def add_balances(self, balance):
        self.balances.append(balance)
    def get_lastbalance(self):
        if len(self.balances) != 0:
            return self.balances[len(self.balances)-1]
        else:
            return self.balance

    def get_profits(self): return self.profits
    def add_profit(self, newprofit): self.profits.append(newprofit)
    def get_lastprofit(self):
        if len(self.profits) != 0:
            return self.profits[len(self.profits)-1]
        else:
            return 0


    def get_boats(self): return self.boats
    def add_boat(self, boat): self.boats.append(boat)
    def get_boat(self, boatname):
        for r in self.boats:
            if r.get_name() == boatname:
                return r


    def get_cargoList(self): return self.cargoList
    def add_cargo(self, cargo): self.cargoList.append(cargo)
    def get_cargo(self, cargoID):
        for r in self.cargoList:
            if r.get_ID() == cargoID:
                return r

    def addtoship_cargo(self, boat, cargo):
        boat.add_cargo(cargo)
        self.cargoList.remove(cargo)


    def buy_fuel(self, portname, amount):
        from Ports import Port
        port = Port.get_port(portname)
        self.fuel += amount
        self.balance -= amount * port.get_fuelprice()

    def addtoship_fuel(self, boatname, amount):
        boat = self.get_boat(boatname)
        boat.add_fuel(amount)
        self.fuel -= amount

    def pay_opCost(self, boat):
        self.balance -= int(boat.get_opCost())

class Cargo(object):
    allCargo = []
    numMade = 0

    def __init__(self, units, contrval, start, dest):
        self.ID = Cargo.numMade
        self.units = units
        self.contrval = contrval # delivery contract value set by cargo owner
        self.currLoc = None
        self.start = start
        self.dest = dest
        Cargo.allCargo.append(self)
        Cargo.numMade += 1

    def get_ID(self): return self.ID

    def get_units(self): return self.units

    def get_contrval(self): return self.contrval

    def get_currLoc(self): return self.currLoc
    def set_currLoc(self, newcurrLoc): self.currLoc = newcurrLoc

    def get_start(self): return self.start

    def get_dest(self): return self.dest
