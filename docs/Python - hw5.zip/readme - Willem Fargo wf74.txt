

Ship Model

The Project Description:

This project is to model a shipping network using ships, ports and sea routes.
Classes for Ships, Ports, and sea routes are needed.
Distances between ports vary as some routes are short sea voyages and some are longer voyages.

Ships enter port, but may need to wait for a dock to be available.
Ships may anchor in a port until a dock is available.

A commerce model needs to be built.   The Fleet manager (you) needs to pay for daily operating costs of the vessel, as well as fuel costs, docking, anchoring and loading fees.  These operating costs are offset by taking delivery contracts from freight forwarders for bringing goods to different ports.  An account balance is maintained, and profit or loss can be determined based decisions made - which cargo to select and which ports and routes are most profitable.

Data is brought in by data files and can be backed up and saved. A graphical GUI was utilized to visualize the simulation.


Program Structure:
During the course of this work - the simulation was built off the work we learned during the bus model, and the commerce model we did in class.  The structure of the bus model example proved to be a good basis for fleshing out the ship network.   I added some complexity with varying the lengths of routes, putting ships on specific x, y co-ordinates and trying to add to the commerce model.  I used classes to manage my framework.  Also, I used extensive function scripts as this proved necessary working with tkinter.

I enjoyed the challenge of building my own problem - and I tried to make sure the concept could be developed with the right amount of variables, and complexity.   

I spent too much time on 2 areas that got me stuck. Originally I built a "routing" program in a 100x100 grid of nodes that also had a "weather" component - a z factor.   I wanted to model shortest path to a destination and compare with the "least" wavy.  I was successful in getting the model built - using random values for Z..   but I struggled with the recursion on a mesh network versus the node trees we learned in class.  It was interesting and I wanted to pursue this but had to shelve due to time.
I did get some variation of most direct vs "wave avoidance" - but only by manually looking forward 4 points versus recursing the full pathway on a 100 x 100 grid like a real weather routing system would.   

The other area I experimented with was the tkinter GUI program.   This part I really enjoyed and spent much of the time trying to get a good looking program GUI.   The loop nature of tkinter was a bit difficult to figure out, until I started nesting some functions.   In the end, I feel like I learned alot about tkinter, but need more time to get skilled as I couldn't figure out easy ways to get data back and refresh/renew destroy() my map grid.

The next steps on this model would be to fix my weird x-y coordinates in a better way, and than to build out complexity in the commerce engine to make the simulation illustrate tradeoffs.
